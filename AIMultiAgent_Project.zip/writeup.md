A.I. Multi-Agent Study Assistant

Subtitle: Autonomous multi-agent study planner that creates, tracks, and adapts personalized study plans.

Problem Statement
Students often struggle to create consistent, prioritized, and adaptable study schedules. Schedules must respect individual availability, handle missed sessions, and recommend learning resources. Manual re-planning costs time and reduces focus.

Proposed Solution
I built the A.I. Multi-Agent Study Assistant, a modular multi-agent system that:
- Automatically detects availability and constraints (Scheduler Agent).
- Breaks curriculum into prioritized study tasks and maps them to time slots (Study Planner Agent).
- Tracks progress and adapts the plan when sessions are missed (Progress Tracker Agent).
- Recommends targeted resources per topic (Resource Recommender Agent).
