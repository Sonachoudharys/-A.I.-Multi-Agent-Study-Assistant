import time
from typing import Dict, Any, List
class MemoryBank:
    def __init__(self):
        self.store = {}
    def get(self, key, default=None):
        return self.store.get(key, default)
    def set(self, key, value):
        self.store[key] = value
    def append_log(self, key, entry):
        self.store.setdefault(key, []).append(entry)
class BaseAgent:
    def __init__(self, name: str, memory: MemoryBank):
        self.name = name
        self.memory = memory
    def act(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        raise NotImplementedError
# Agents implementations similar to notebook for reuse.
