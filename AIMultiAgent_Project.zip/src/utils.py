def evaluate_plan_stub(plan):
    return {"score": 0.5}
