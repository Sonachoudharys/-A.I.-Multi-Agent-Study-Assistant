# Simple orchestrator example (import agents and memory)
from src.memory import MemoryBank
from src.agents import BaseAgent
# In a real app, orchestrator creates agent instances and manages session state.
class Orchestrator:
    def __init__(self):
        self.memory = MemoryBank()
    def run_plan(self, topics):
        return {"status": "stub", "topics": topics}
